<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard | RENT.ID</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: #ffffff;
      color: #0B0146;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      overflow-x: hidden;
      zoom: 0.9;
    }

    /* Navbar */
    nav {
      background-color: #AFC8FF;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.2rem 5rem;
      box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
      width: 100%;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 2.5rem;
    }

    nav ul li a {
      text-decoration: none;
      color: #ffffff;
      font-weight: 500;
      font-size: 1.1rem;
      position: relative;
      transition: 0.2s;
    }

    nav ul li a:hover {
      opacity: 0.8;
    }

    nav ul li a.active {
      color: #ffffff;
      font-weight: 700;
    }

    nav ul li a.active::after {
      content: "";
      position: absolute;
      bottom: -6px;
      left: 0;
      width: 100%;
      height: 2px;
      background-color: #ffffff;
      border-radius: 2px;
    }

    .logout-btn {
      background: #ffffff;
      color: #91b1ff;
      border: none;
      border-radius: 50px;
      padding: 0.6rem 2rem;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    .logout-btn:hover {
      background: #f3f6ff;
      color: #6d9cff;
    }

    /* Content */
    .container {
      flex: 1;
      width: 100%;
      padding: 3.5rem 8rem 3rem 8rem;
      display: flex;
      flex-direction: column;
      gap: 4rem;
    }

    /* Welcome Section */
    .welcome {
      text-align: left;
    }

    .welcome h1 {
      font-size: 3.4rem;
      font-weight: 800;
      color: #0B0146;
      line-height: 1.2;
      margin-bottom: 1rem;
    }

    .welcome h1 span {
      display: block;
      color: #0B0146;
      font-size: 3.6rem;
    }

    .welcome p {
      font-size: 1.2rem;
      color: #444;
      max-width: 900px;
      margin-top: 2rem;
      font-weight: 600;
      line-height: 1.7;
    }

    .welcome p span {
      display: block;
    }

    /* Stats Section */
    .stats {
      display: flex;
      justify-content: center;
      gap: 14rem;
      flex-wrap: wrap;
      margin-top: 1.5rem;
    }

    .stat-item {
      text-align: center;
    }

    .stat-item p.label {
      font-weight: 600;
      color: #0B0146;
      font-size: 1rem;
      margin-bottom: 0.8rem;
    }

    /* OVAL ELEGAN */
    .oval {
      width: 280px;
      height: 110px;
      background: linear-gradient(145deg, #e9e8f0, #ffffff);
      border-radius: 70px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
      margin: 0 auto;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .oval:hover {
      transform: translateY(-6px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.18);
    }

    .oval h3 {
      font-size: 2.8rem;
      font-weight: 800;
      color: #0B0146;
      letter-spacing: 1px;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 1rem 0;
      background: #ffffff;
      margin-top: auto;
    }

    footer img {
      width: 250px;
      height: 250px;
      margin: -70px auto 0 auto; 
      opacity: 0.9;
      display: block;
    }

    footer p {
      color: #0B0146;
      font-weight: 600;
      font-size: 0.9rem;
      margin-top: 0.5rem;
    }

    /* Responsive */
    @media (max-width: 768px) {
      nav {
        flex-direction: column;
        gap: 1rem;
      }
      nav ul {
        flex-wrap: wrap;
        justify-content: center;
      }
      .container {
        padding: 2rem;
      }
      .stats {
        flex-direction: column;
        align-items: center;
        gap: 3rem;
      }
      .welcome h1 {
        font-size: 2.2rem;
      }
      footer img {
        width: 200px;
        height: 200px;
        margin-top: -30px; 
      }
      .oval {
        width: 240px;
        height: 95px;
      }
      .oval h3 {
        font-size: 2.4rem;
      }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav>
    <ul>
      <li><a href="#">Profile</a></li>
      <li><a href="#" class="active">Dashboard</a></li>
      <li><a href="#">Rentals</a></li>
      <li><a href="#">Customer</a></li>
      <li><a href="#">Payment</a></li>
      <li><a href="#">Reports</a></li>
      <li><a href="#">Settings</a></li>
    </ul>
    <button class="logout-btn">Logout</button>
  </nav>

  <!-- Content -->
  <div class="container">
    <div class="welcome">
      <h1>Welcome to your<br><span>Dashboard!</span></h1>
      <p>
        <strong>Manage all your rentals, track payments, and stay on top of</strong>
        <span><strong>every transaction — all in one place.</strong></span>
      </p>
    </div>

    <div class="stats">
      <div class="stat-item">
        <p class="label">Jumlah Penyewa</p>
        <div class="oval">
          <h3>110</h3>
        </div>
      </div>

      <div class="stat-item">
        <p class="label">Kendaraan Disewakan</p>
        <div class="oval">
          <h3>5</h3>
        </div>
      </div>

      <div class="stat-item">
        <p class="label">Transaksi Aktif</p>
        <div class="oval">
          <h3>3</h3>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <footer>
    <img src=".asset/logo.png" alt="Logo RENT.ID" />
  </footer>
</body>
</html>

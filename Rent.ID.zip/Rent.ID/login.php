<?php
include 'koneksi.php';
//session_start();
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama']);
    $password = trim($_POST['password']);

    if (empty($nama) || empty($password)) {
        $message = "Semua kolom wajib diisi.";
    } else {
        // Cek di tabel mitra
        $queryMitra = "SELECT id_mitra AS id, nama_mitra AS nama, password FROM mitra WHERE nama_mitra = ?";
        $stmt = $conn->prepare($queryMitra);
        $stmt->bind_param("s", $nama);
        $stmt->execute();
        $resultMitra = $stmt->get_result();

        if ($resultMitra->num_rows > 0) {
            $user = $resultMitra->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['id'] = $user['id'];
                $_SESSION['nama'] = $user['nama'];
                $_SESSION['role'] = 'mitra';
                header("Location: Dashboard_Mitra.php");
                exit;
            } else {
                $message = "Password atau username salah.";
            }
        } else {
            // Cek di customer
            $queryCustomer = "SELECT id_customer AS id, nama, password FROM customer WHERE nama = ?";
            $stmt = $conn->prepare($queryCustomer);
            $stmt->bind_param("s", $nama);
            $stmt->execute();
            $resultCustomer = $stmt->get_result();

            if ($resultCustomer->num_rows > 0) {
                $user = $resultCustomer->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['id'] = $user['id'];
                    $_SESSION['nama'] = $user['nama'];
                    $_SESSION['role'] = 'customer';
                    header("Location: dashboard_Customer.php");
                    exit;
                } else {
                    $message = "Password atau username salah.";
                }
            } else {
                $message = "Username tidak ditemukan.";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Rent.id</title>

    <!-- Font Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: url('.asset/BG PROJEK.jpg') no-repeat center center/cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: #fff;
            width: 400px;
            padding: 40px 40px 30px;
            border-radius: 20px;
            box-shadow: 0px 4px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #93BAFF;
            font-weight: 600;
            font-size: 20px;
            margin-bottom: 30px;
        }

        .login-box input[type="text"],
        .login-box input[type="password"] {
            width: 100%;
            padding: 10px 5px;
            margin: 10px 0 20px;
            border: none;
            border-bottom: 1px solid #ccc;
            outline: none;
            font-size: 14px;
            color: #333;
        }

        .login-box button {
            background: #93BAFF;
            border: none;
            color: white;
            padding: 12px 0;
            width: 100%;
            border-radius: 8px;
            font-weight: 500;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(147, 186, 255, 0.3);
        }

        .login-box button:hover {
            background: #82acf8;
            transform: scale(1.02);
        }

        .register-link {
            margin-top: 20px;
            font-size: 13px;
            color: #555;
        }

        .register-link a {
            color: #93BAFF;
            text-decoration: none;
            font-weight: 500;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 13px;
            margin-bottom: 15px;
        }

        .show-pass {
            display: flex;
            align-items: center;
            justify-content: start;
            font-size: 13px;
            color: #555;
        }

        .show-pass input {
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2>Selamat Datang<br>di Rent.id</h2>

        <?php if (!empty($message)) echo "<p class='error-message'>$message</p>"; ?>

        <form method="POST" action="">
            <input type="text" name="nama" placeholder="Username" required>
            <input type="password" id="password" name="password" placeholder="Password" required>

            <button type="submit">Login</button>

            <div class="register-link">
                Belum punya akun? <a href="register.php">Daftar di sini.</a>
            </div>
        </form>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById("password");
            const checkbox = document.getElementById("showPassword");
            passwordField.type = checkbox.checked ? "text" : "password";
        }
    </script>
</body>
</html>

<!-- login customer pelanggan1 pass = cust123 --> 
 <!-- Login mitra motor pass = motor123 -->
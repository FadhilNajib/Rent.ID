<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role = $_POST['role'];
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validasi input kosong
    if (empty($role) || empty($nama) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "Semua kolom wajib diisi.";
        exit;
    }

    // Cek apakah password dan konfirmasi sama
    if ($password !== $confirm_password) {
        echo "Password dan Konfirmasi Password tidak cocok.";
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if ($role === 'mitra') {
        $stmt = $conn->prepare("INSERT INTO mitra (nama_mitra, password, email) VALUES (?, ?, ?)");
    } elseif ($role === 'customer') {
        $stmt = $conn->prepare("INSERT INTO customer (nama, password, email, tanggal_daftar) VALUES (?, ?, ?, NOW())");
    } else {
        echo "Role tidak valid.";
        exit;
    }

    $stmt->bind_param("sss", $nama, $hashed_password, $email);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit;
    } else {
        echo "Terjadi kesalahan: " . $conn->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Rent.id</title>

    <!-- Font Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
    background: url('.asset/BG PROJEK.jpg') no-repeat center center/cover;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0 20px; /* ➜ buat jaga kalau layar kecil */
}


        .register-box {
    background: #fff;
    width: 460px; /* ➜ dilebarin dari 400px */
    padding: 40px 50px 35px; /* ➜ padding kanan kiri lebih lega, bawah sedikit dikurangi */
    border-radius: 25px;
    box-shadow: 0px 6px 30px rgba(0, 0, 0, 0.1);
    text-align: center;
    transform: translateY(-20px); /* ➜ sedikit dinaikkan biar lebih tengah */
}


        h2 {
            color: #93BAFF;
            font-weight: 600;
            font-size: 20px;
            margin-bottom: 30px;
        }

        .register-box input[type="text"],
        .register-box input[type="email"],
        .register-box input[type="password"] {
            width: 100%;
            padding: 10px 5px;
            margin: 10px 0 20px;
            border: none;
            border-bottom: 1px solid #ccc;
            outline: none;
            font-size: 14px;
            color: #333;
        }

        .role-choice {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 25px;
            font-size: 14px;
            margin-bottom: 25px;
            color: #555;
        }

        .register-box button {
            background: #93BAFF;
            border: none;
            color: white;
            padding: 12px 0;
            width: 100%;
            border-radius: 8px;
            font-weight: 500;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(147, 186, 255, 0.3);
        }

        .register-box button:hover {
            background: #82acf8;
            transform: scale(1.02);
        }

        .register-link {
            margin-top: 20px;
            font-size: 13px;
            color: #555;
        }

        .register-link a {
            color: #93BAFF;
            text-decoration: none;
            font-weight: 500;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .show-pass {
            display: flex;
            align-items: center;
            justify-content: start;
            font-size: 13px;
            color: #555;
            margin-bottom: 20px;
        }

        .show-pass input {
            margin-right: 5px;
        }

        .role-selection {
  margin-top: 20px;
  text-align: left;
  margin-bottom: 20px;
}

.role-label {
  display: block;
  font-size: 14px;
  color: #999;
  margin-bottom: 8px;
  font-weight: 500;
}

.role-options label {
  font-family: 'Poppins', sans-serif;
  color: #777;
  font-size: 15px;
  margin-right: 30px;
}

.role-options input[type="radio"] {
  margin-right: 8px;
  accent-color: #93BAFF; /* warna biru sesuai tema lo */
}

    </style>
</head>

<body>
    <div class="register-box">
        <h2>Selamat Datang<br>di Rent.id</h2>

        <form method="POST" action="">
            <input type="text" name="nama" placeholder="Nama" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Password" required>

            <div class="role-selection">
  <label class="role-label">Buat akun sebagai:</label>
  <div class="role-options">
  <label><input type="radio" name="role" value="customer"> Penyewa</label>
  <label><input type="radio" name="role" value="mitra"> Pemilik rental</label>
</div>

</div>


            <button type="submit">Register</button>

            <div class="register-link">
                Sudah punya akun? <a href="login.php">Login di sini.</a>
            </div>
        </form>
    </div>

    <script>
        function togglePassword() {
            const password = document.getElementById("password");
            const confirm = document.getElementById("confirm_password");
            const checkbox = document.getElementById("showPassword");
            const type = checkbox.checked ? "text" : "password";
            password.type = type;
            confirm.type = type;
        }
    </script>
</body>
</html>
